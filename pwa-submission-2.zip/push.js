let webPush = require("web-push");

const vapidKeys = {
	publicKey:
		"BMtmfCH2FIG9K_cXUtCQQYRjV0ECVkxuPLePPpvjLmnUjApEnuJGMQfQjw3adBaHsZzoGdgBPc_Pq_AFl63OlqQ",
	privateKey: "o0JRfJDvJyGTb_XwnIupyjKmZntGShONMW7-p_F_ZDQ",
};

webPush.setVapidDetails(
	"mailto:example@yourdomain.org",
	vapidKeys.publicKey,
	vapidKeys.privateKey
);

let pushSubscription = {
	endpoint:
		"https://fcm.googleapis.com/fcm/send/cd0PtdkB3Vs:APA91bHu6gynTe0RKFW7nVSWNm3LOULsoFuAf5m3vZro8gZX4IB-YV4ur2Ue5TsKa22BHvF_g2CQa04u8WWe2pMuDwCxFyjLKkvTo1HZqN8a544sbCwuynHqzDd2CyLbz5Nu8kHNNWyn",
	keys: {
		p256dh:
			"BO8fO8yjBJ/HTyqTufdfcRTQq/MrD/r0kGNI2pJhm4dAH94EHwTxPPK+KjAhaMQykAzPGLAiLO/tyM+lwx7WL5U=",
		auth: "0OMSqoyqUGppIsOeLQxyAw==",
	},
};
let payload = "Push Notification from Football Apps";

let options = {
	gcmAPIKey: "810879853303",
	TTL: 60,
};

webPush.sendNotification(pushSubscription, payload, options);
